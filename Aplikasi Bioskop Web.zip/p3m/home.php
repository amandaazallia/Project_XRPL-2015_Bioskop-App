<body style="background:black">
<!DOCTYPE HTML>

<html>
	<head><link rel="icon"type="image/png" href="img/favicon.png">			
		<title>In-Man</title>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
			<link rel="stylesheet" type="text/css" href="home.css" />
			<body>
				<div id="container">
					<div id="header">
						<div id="logo"><img src="logo2.png"></div>
						<div id="content-menu">
							<a class="link" href="home.php"><div class="menu-child">HOME</div></a>
							<a class="link" href="schedule.php"><div class="menu-child">SCHEDULE</div></a>
							<a class="link" href="show.php"><div class="menu-child">SHOW</div></a>
							<a class="link" href="about.php"><div class="menu-child">ABOUT</div></a>
							<a class="link" href="admin.php"><div class="menu-child">LOG IN</div></a>
						</div>
						<div id="home1">
							<div class="divimagebanner">
		
										<div id="slider2">
												<div id="mask">
														<ul>
																		<li><a href="#"><img src="img/slide12.jpg" width="1000px" height="440px"></a></li>
																		<li><a href="#"><img src="img/1.png" width="1000px" height="440px"></a></li>
																		<li><a href="#"><img src="img/slide2.png" width="1000px" height="440px"></a></li>
																		<li><a href="#"><img src="img/slide7.jpg" width="1000px" height="440px"></a></li>
														</ul>
												</div>
								<div id="progress"></div>
								<div id="overlay"></div>
								<div id="pause"></div>
							</div>
									
								</div>
						</div>
							
						<div id="home2">
						<div id="judul">T R A I L L E R</div>
							<div class="trailer1">
							
								<center><h4 class="title1">INSIDIOUS 3</h4></center>
								<iframe width="390" height="360" frameborder="0" allowfullscreen="" src="https://wwww.youtube.com/embed/3HxEXnVSr1w"></iframe>
							</div>
							
							<div class="trailer2">
							<center><h4 class="title2">FINDING DORI</h4></center>
								<iframe width="390" height="360" src="https://wwww.youtube.com/embed/TAXZRzj5AQ" frameborder="0" allowfullscreen=""></iframe>
							</div>
						
							<div class="trailer3">
								<center><h4 class="title3">LDR</h4></center>
								<iframe width="390" height="360" src="https://wwww.youtube.com/embed/6-Jw4rEQXi0" frameborder="0" allowfullscreen=""></iframe>
							</div>
						</div>
						<center><div class="footer"><img src="footer7.png" ></div></center>
						
				</div>
				</body>
	</head>