<body style="background:black">
<!DOCTYPE HTML>

<html>
	<head><link rel="icon"type="image/png" href="img/favicon.png">			
		<title>In-Man</title>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
			<link rel="stylesheet" type="text/css" href="admin.css" />
			<body>
				<div id="container">
					<div id="header">
						<div id="logo"><img src="logo2.png"></div>
						<div id="content-menu">
							<a class="link" href="home.php"><div class="menu-child">HOME</div></a>
							<a class="link" href="schedule.php"><div class="menu-child">SCHEDULE</div></a>
							<a class="link" href="show.php"><div class="menu-child">SHOW</div></a>
							<a class="link" href="about.php"><div class="menu-child">ABOUT</div></a>
							<a class="link" href="about.php"><div class="menu-child">LOG IN</div></a>
						</div></div>
						
					<div id="form-admin">
						<form action="proses.php" METHOD="POST">
						<input class="nama_login"  type="text" name="username" PlaceHolder="Username"/><p>
						<input class="pass" type="password" PlaceHolder="Password" name="password"/><p>
						<input class="button" type="submit" value="Masuk" name="admin"/>
							</div>
							
								<table border="0 " align="center">
										<tr> <align="center" valign="baseline">
											<td><center><marquee class="hs" ></marquee></td></font>
											
										</tr>
								</table>
							
							
							<center><div class="footer"><img src="footer7.png" ></div></center>
					</div>
		</head>
</html>
				