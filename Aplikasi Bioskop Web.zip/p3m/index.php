<!DOCTYPE HTML>
	<html>
		<head><link rel="icon"type="image/png" href="img/favicon.png">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
			<link rel="stylesheet" type="text/css" href="index.css" />
			<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
			<body>
				<title>In-Man Cooperation</title> 
				<div id="container">
					<center><div class="logo"><img src="logo2.png"></div></center>
					<div class="menu-1"></div>
					<div class="menu-2"></div>
					<div class="menu-3"></div>
					<div class="menu-4"></div>
					<a class="link" href="about.php"><div class="menu-home"><img class="about" src="about2.png"></div>
					<a class="link" href="show.php"><div class="menu-schedule"><img class="shows" src="shows.png"></div>
					<a class="link" href="schedule.php"><div class="menu-show" ><img class="schedule" src="schedule3.png"></div>
					<a class="link" href="home.php"><div class="menu-about"><img class="home" src="home5.png"></div>
				<div class="footer"><img src="footer7.png" ></div>
				</div>
			</body>
		</head>
	</html>